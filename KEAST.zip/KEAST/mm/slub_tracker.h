/*********************************************************************************
* Copyright(C),2013-2017,MediaTek Inc.
* FileName:	slub_tracker.h
* Author:		Guangye.Yang
* Version:	V1.2
* Date:		2013/9/29
* Description: slubģ�����
**********************************************************************************/
#ifndef _SLUB_TRACKER_H
#define _SLUB_TRACKER_H

/*************************************************************************
* DESCRIPTION
*	����slubϵͳ
*
* PARAMETERS
*	fp: �ļ����
*
* RETURNS
*	��
*
* GLOBAL AFFECTED
*
*************************************************************************/
void SlubTrack(FILE *fp);

#endif
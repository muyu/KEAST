/*********************************************************************************
* Copyright(C),2014-2017,MediaTek Inc.
* FileName:	script_int.h
* Author:		Guangye.Yang
* Version:	V1.0
* Date:		2014/11/3
* Description: �ű��ڲ�ͷ�ļ�
**********************************************************************************/
#ifndef _SCRIPT_INT_H
#define _SCRIPT_INT_H

#define UTILS_DIR   "scrutils"

#endif
